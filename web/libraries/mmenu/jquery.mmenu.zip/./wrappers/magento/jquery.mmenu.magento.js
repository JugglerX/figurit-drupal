/*
 * Magento wrapper for jQuery mmenu
 * Include this file after including the jquery.mmenu plugin for default Magento support.
 */
!function(e){var a="mmenu";e[a].configuration.classNames.selected="active"}(jQuery);